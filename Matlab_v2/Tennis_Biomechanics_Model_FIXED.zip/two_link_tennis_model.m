function [M, C, G, B] = two_link_tennis_model(theta, theta_dot, params)
%TWO_LINK_TENNIS_MODEL Computes dynamics matrices for two-link arm model
%
% This function computes the mass matrix (M), Coriolis/centrifugal matrix (C),
% gravity vector (G), and input matrix (B) for a two-link planar arm model
% representing the upper arm and forearm+racket segments.
%
% Inputs:
%   theta     - Joint angles [theta1; theta2] (rad) - 2x1 vector
%   theta_dot - Joint angular velocities [theta1_dot; theta2_dot] (rad/s) - 2x1 vector
%   params    - Structure containing model parameters:
%               .l1  - Upper arm length (m)
%               .l2  - Forearm + racket length (m)
%               .m1  - Upper arm mass (kg)
%               .m2  - Forearm + racket mass (kg)
%               .lc1 - Distance to upper arm COM (m)
%               .lc2 - Distance to forearm+racket COM (m)
%               .I1  - Upper arm moment of inertia (kg*m^2)
%               .I2  - Forearm+racket moment of inertia (kg*m^2)
%               .g   - Gravitational acceleration (m/s^2)
%
% Outputs:
%   M - 2x2 Mass (inertia) matrix
%   C - 2x2 Coriolis and centrifugal matrix
%   G - 2x1 Gravity vector
%   B - 2x2 Input mapping matrix (identity for fully actuated system)
%
% Dynamics equation: M(theta)*theta_ddot + C(theta,theta_dot)*theta_dot + G(theta) = tau
%
% Example:
%   params.l1 = 0.3; params.l2 = 0.35; params.m1 = 2; params.m2 = 1.5;
%   params.lc1 = 0.15; params.lc2 = 0.2; params.I1 = 0.025; params.I2 = 0.045;
%   params.g = 9.81;
%   theta = [0.5; 0.3]; theta_dot = [1; 0.5];
%   [M, C, G, B] = two_link_tennis_model(theta, theta_dot, params);
%
% Author: PhD Research Model
% Date: 2024

%% Input Validation
if nargin < 3
    error('two_link_tennis_model:NotEnoughInputs', ...
          ['Not enough input arguments.\n' ...
           'Usage: [M, C, G, B] = two_link_tennis_model(theta, theta_dot, params)\n' ...
           'Run "help two_link_tennis_model" for more information.']);
end

% Validate theta
if ~isnumeric(theta) || numel(theta) ~= 2
    error('two_link_tennis_model:InvalidTheta', ...
          'theta must be a 2-element numeric vector');
end

% Validate theta_dot
if ~isnumeric(theta_dot) || numel(theta_dot) ~= 2
    error('two_link_tennis_model:InvalidThetaDot', ...
          'theta_dot must be a 2-element numeric vector');
end

% Validate params structure
required_fields = {'l1', 'l2', 'm1', 'm2', 'lc1', 'lc2', 'I1', 'I2', 'g'};
for i = 1:length(required_fields)
    if ~isfield(params, required_fields{i})
        error('two_link_tennis_model:MissingParam', ...
              'params structure missing required field: %s', required_fields{i});
    end
end

%% Extract Parameters
l1 = params.l1;    % Upper arm length (m)
l2 = params.l2;    % Forearm + racket length (m)
m1 = params.m1;    % Upper arm mass (kg)
m2 = params.m2;    % Forearm + racket mass (kg)
lc1 = params.lc1;  % Upper arm COM distance (m)
lc2 = params.lc2;  % Forearm + racket COM distance (m)
I1 = params.I1;    % Upper arm inertia (kg*m^2)
I2 = params.I2;    % Forearm + racket inertia (kg*m^2)
g = params.g;      % Gravity (m/s^2)

% Ensure column vectors
theta = theta(:);
theta_dot = theta_dot(:);

% Extract individual angles and velocities
theta1 = theta(1);
theta2 = theta(2);
theta1_dot = theta_dot(1);
theta2_dot = theta_dot(2);

%% Compute Trigonometric Terms
c1 = cos(theta1);
s1 = sin(theta1);
c2 = cos(theta2);
s2 = sin(theta2);
c12 = cos(theta1 + theta2);
s12 = sin(theta1 + theta2);

%% Compute Mass Matrix M(theta)
% Using the standard formulation for a two-link planar manipulator
% M = [M11, M12; M21, M22]

% Effective inertias
alpha = I1 + I2 + m1*lc1^2 + m2*(l1^2 + lc2^2);
beta = m2*l1*lc2;
delta = I2 + m2*lc2^2;

M11 = alpha + 2*beta*c2;
M12 = delta + beta*c2;
M21 = M12;  % Symmetric matrix
M22 = delta;

M = [M11, M12; M21, M22];

%% Compute Coriolis and Centrifugal Matrix C(theta, theta_dot)
% Using Christoffel symbols formulation
% C = [C11, C12; C21, C22]

h = -m2*l1*lc2*s2;

C11 = h*theta2_dot;
C12 = h*(theta1_dot + theta2_dot);
C21 = -h*theta1_dot;
C22 = 0;

C = [C11, C12; C21, C22];

%% Compute Gravity Vector G(theta)
% G = [G1; G2]

G1 = (m1*lc1 + m2*l1)*g*c1 + m2*lc2*g*c12;
G2 = m2*lc2*g*c12;

G = [G1; G2];

%% Input Matrix B
% For a fully actuated system with torque inputs at each joint
B = eye(2);

end
