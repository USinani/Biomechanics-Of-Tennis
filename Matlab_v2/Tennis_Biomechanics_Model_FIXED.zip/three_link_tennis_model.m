function [M, C, G, B] = three_link_tennis_model(theta, theta_dot, params)
%THREE_LINK_TENNIS_MODEL Computes dynamics matrices for three-link arm model
%
% This function computes the mass matrix (M), Coriolis/centrifugal matrix (C),
% gravity vector (G), and input matrix (B) for a three-link planar arm model
% representing the upper arm, forearm, and racket segments.
%
% Inputs:
%   theta     - Joint angles [theta1; theta2; theta3] (rad) - 3x1 vector
%               theta1: shoulder angle
%               theta2: elbow angle  
%               theta3: wrist angle
%   theta_dot - Joint angular velocities (rad/s) - 3x1 vector
%   params    - Structure containing model parameters:
%               .l1  - Upper arm length (m)
%               .l2  - Forearm length (m)
%               .l3  - Racket length (m)
%               .m1  - Upper arm mass (kg)
%               .m2  - Forearm mass (kg)
%               .m3  - Racket mass (kg)
%               .lc1 - Distance to upper arm COM (m)
%               .lc2 - Distance to forearm COM (m)
%               .lc3 - Distance to racket COM (m)
%               .I1  - Upper arm moment of inertia (kg*m^2)
%               .I2  - Forearm moment of inertia (kg*m^2)
%               .I3  - Racket moment of inertia (kg*m^2)
%               .g   - Gravitational acceleration (m/s^2)
%
% Outputs:
%   M - 3x3 Mass (inertia) matrix
%   C - 3x3 Coriolis and centrifugal matrix
%   G - 3x1 Gravity vector
%   B - 3x3 Input mapping matrix (identity for fully actuated system)
%
% Dynamics equation: M(theta)*theta_ddot + C(theta,theta_dot)*theta_dot + G(theta) = tau
%
% Example:
%   params.l1 = 0.3; params.l2 = 0.25; params.l3 = 0.68;
%   params.m1 = 2; params.m2 = 1.2; params.m3 = 0.34;
%   params.lc1 = 0.15; params.lc2 = 0.12; params.lc3 = 0.34;
%   params.I1 = 0.025; params.I2 = 0.015; params.I3 = 0.015;
%   params.g = 9.81;
%   theta = [0.5; 0.3; 0.1]; theta_dot = [1; 0.5; 0.2];
%   [M, C, G, B] = three_link_tennis_model(theta, theta_dot, params);
%
% Author: PhD Research Model
% Date: 2024

%% Input Validation
if nargin < 3
    error('three_link_tennis_model:NotEnoughInputs', ...
          ['Not enough input arguments.\n' ...
           'Usage: [M, C, G, B] = three_link_tennis_model(theta, theta_dot, params)\n' ...
           'Run "help three_link_tennis_model" for more information.']);
end

% Validate theta
if ~isnumeric(theta) || numel(theta) ~= 3
    error('three_link_tennis_model:InvalidTheta', ...
          'theta must be a 3-element numeric vector');
end

% Validate theta_dot
if ~isnumeric(theta_dot) || numel(theta_dot) ~= 3
    error('three_link_tennis_model:InvalidThetaDot', ...
          'theta_dot must be a 3-element numeric vector');
end

% Validate params structure
required_fields = {'l1', 'l2', 'l3', 'm1', 'm2', 'm3', 'lc1', 'lc2', 'lc3', 'I1', 'I2', 'I3', 'g'};
for i = 1:length(required_fields)
    if ~isfield(params, required_fields{i})
        error('three_link_tennis_model:MissingParam', ...
              'params structure missing required field: %s', required_fields{i});
    end
end

%% Extract Parameters
l1 = params.l1;    % Upper arm length (m)
l2 = params.l2;    % Forearm length (m)
l3 = params.l3;    % Racket length (m)
m1 = params.m1;    % Upper arm mass (kg)
m2 = params.m2;    % Forearm mass (kg)
m3 = params.m3;    % Racket mass (kg)
lc1 = params.lc1;  % Upper arm COM distance (m)
lc2 = params.lc2;  % Forearm COM distance (m)
lc3 = params.lc3;  % Racket COM distance (m)
I1 = params.I1;    % Upper arm inertia (kg*m^2)
I2 = params.I2;    % Forearm inertia (kg*m^2)
I3 = params.I3;    % Racket inertia (kg*m^2)
g = params.g;      % Gravity (m/s^2)

% Ensure column vectors
theta = theta(:);
theta_dot = theta_dot(:);

% Extract individual angles
q1 = theta(1);  % Shoulder
q2 = theta(2);  % Elbow
q3 = theta(3);  % Wrist

% Extract individual velocities
q1_dot = theta_dot(1);
q2_dot = theta_dot(2);
q3_dot = theta_dot(3);

%% Compute Trigonometric Terms
c1 = cos(q1);
s1 = sin(q1);
c2 = cos(q2);
s2 = sin(q2);
c3 = cos(q3);
s3 = sin(q3);

c12 = cos(q1 + q2);
s12 = sin(q1 + q2);
c23 = cos(q2 + q3);
s23 = sin(q2 + q3);
c123 = cos(q1 + q2 + q3);
s123 = sin(q1 + q2 + q3);

%% Compute Mass Matrix M(theta)
% 3x3 symmetric positive definite mass matrix

% Effective parameters
a1 = I1 + I2 + I3 + m1*lc1^2 + m2*(l1^2 + lc2^2) + m3*(l1^2 + l2^2 + lc3^2);
a2 = m2*l1*lc2 + m3*l1*l2;
a3 = m3*l1*lc3;
a4 = I2 + I3 + m2*lc2^2 + m3*(l2^2 + lc3^2);
a5 = m3*l2*lc3;
a6 = I3 + m3*lc3^2;

% Mass matrix elements
M11 = a1 + 2*a2*c2 + 2*a3*c23 + 2*a5*c3;
M12 = a4 + a2*c2 + a3*c23 + 2*a5*c3;
M13 = a6 + a3*c23 + a5*c3;
M22 = a4 + 2*a5*c3;
M23 = a6 + a5*c3;
M33 = a6;

M = [M11, M12, M13;
     M12, M22, M23;
     M13, M23, M33];

%% Compute Coriolis and Centrifugal Matrix C(theta, theta_dot)
% Using Christoffel symbols formulation

h1 = -m2*l1*lc2*s2 - m3*l1*l2*s2;
h2 = -m3*l1*lc3*s23;
h3 = -m3*l2*lc3*s3;

% Coriolis matrix elements
C11 = h1*q2_dot + h2*(q2_dot + q3_dot) + h3*q3_dot;
C12 = h1*(q1_dot + q2_dot) + h2*(q1_dot + q2_dot + q3_dot) + h3*q3_dot;
C13 = h2*(q1_dot + q2_dot + q3_dot) + h3*(q1_dot + q2_dot + q3_dot);
C21 = -h1*q1_dot - h2*q1_dot;
C22 = h3*q3_dot;
C23 = h3*(q1_dot + q2_dot + q3_dot);
C31 = -h2*q1_dot - h3*(q1_dot + q2_dot);
C32 = -h3*(q1_dot + q2_dot);
C33 = 0;

C = [C11, C12, C13;
     C21, C22, C23;
     C31, C32, C33];

%% Compute Gravity Vector G(theta)

G1 = (m1*lc1 + m2*l1 + m3*l1)*g*c1 + (m2*lc2 + m3*l2)*g*c12 + m3*lc3*g*c123;
G2 = (m2*lc2 + m3*l2)*g*c12 + m3*lc3*g*c123;
G3 = m3*lc3*g*c123;

G = [G1; G2; G3];

%% Input Matrix B
% For a fully actuated system with torque inputs at each joint
B = eye(3);

end
