# Tennis Biomechanics MATLAB Model

## PhD Research Model - Tennis Swing Dynamics Simulation

This MATLAB package provides a comprehensive simulation of tennis swing biomechanics using multi-link arm models. It includes forward and inverse dynamics computation, ball trajectory simulation with aerodynamics, and ball-racket impact analysis.

---

## Quick Start

### Run the Complete Simulation
```matlab
>> run_tennis_simulation
```

### Test All Functions
```matlab
>> test_all_functions
```

---

## File Descriptions

| File | Description |
|------|-------------|
| `run_tennis_simulation.m` | **Main script** - Initializes parameters and runs complete simulation |
| `two_link_tennis_model.m` | Computes dynamics matrices for two-link arm model |
| `three_link_tennis_model.m` | Computes dynamics matrices for three-link arm model |
| `compute_forward_dynamics.m` | Computes joint accelerations from applied torques |
| `compute_inverse_dynamics.m` | Computes required torques for desired motion |
| `ball_trajectory_simulator.m` | Simulates ball trajectory with aerodynamics |
| `ball_racket_toy.m` | Models ball-racket impact mechanics |
| `generate_enhanced_summary_report.m` | Generates comprehensive analysis report |
| `test_all_functions.m` | Tests all functions for verification |

---

## Usage Examples

### Using Individual Functions

#### Two-Link Model Dynamics
```matlab
% Define parameters
params.l1 = 0.30;   % Upper arm length (m)
params.l2 = 0.35;   % Forearm + racket length (m)
params.m1 = 2.0;    % Upper arm mass (kg)
params.m2 = 1.5;    % Forearm + racket mass (kg)
params.lc1 = 0.15;  % Upper arm COM distance (m)
params.lc2 = 0.20;  % Forearm + racket COM distance (m)
params.I1 = 0.025;  % Upper arm inertia (kg*m^2)
params.I2 = 0.045;  % Forearm + racket inertia (kg*m^2)
params.g = 9.81;    % Gravity (m/s^2)

% Joint state
theta = [0.5; 0.3];      % Joint angles (rad)
theta_dot = [1.0; 0.5];  % Joint velocities (rad/s)

% Get dynamics matrices
[M, C, G, B] = two_link_tennis_model(theta, theta_dot, params);
```

#### Inverse Dynamics
```matlab
theta_ddot = [5.0; 3.0];  % Desired accelerations (rad/s^2)
tau = compute_inverse_dynamics(theta, theta_dot, theta_ddot, params);
fprintf('Required torques: Shoulder = %.2f Nm, Elbow = %.2f Nm\n', tau(1), tau(2));
```

#### Forward Dynamics
```matlab
tau = [10.0; 5.0];  % Applied torques (Nm)
theta_ddot = compute_forward_dynamics(theta, theta_dot, tau, params);
fprintf('Resulting accelerations: %.2f, %.2f rad/s^2\n', theta_ddot(1), theta_ddot(2));
```

#### Ball Trajectory Simulation
```matlab
ball_initial.position = [0; 1.5; 0];   % Starting position (m)
ball_initial.velocity = [20; 5; 0];     % Initial velocity (m/s)
ball_initial.spin = [0; 0; -100];       % Topspin (rad/s)

ball_params.mass = 0.057;    % Tennis ball mass (kg)
ball_params.radius = 0.0335; % Tennis ball radius (m)
ball_params.Cd = 0.55;       % Drag coefficient
ball_params.Cl = 0.25;       % Lift coefficient
ball_params.rho = 1.225;     % Air density (kg/m^3)
ball_params.g = 9.81;        % Gravity (m/s^2)

[time, state] = ball_trajectory_simulator(ball_initial, ball_params, 2.0);
plot3(state(:,1), state(:,3), state(:,2));
xlabel('X'); ylabel('Z'); zlabel('Y');
title('Ball Trajectory');
```

---

## Model Description

### Two-Link Arm Model
The two-link model represents:
- **Link 1**: Upper arm (shoulder to elbow)
- **Link 2**: Forearm + racket (elbow to racket head)

### Three-Link Arm Model  
The three-link model represents:
- **Link 1**: Upper arm (shoulder to elbow)
- **Link 2**: Forearm (elbow to wrist)
- **Link 3**: Racket (wrist to racket head)

### Dynamics Equations
The models follow the standard manipulator dynamics equation:

```
M(θ)θ̈ + C(θ,θ̇)θ̇ + G(θ) = τ
```

Where:
- `M(θ)`: Mass/inertia matrix (symmetric, positive definite)
- `C(θ,θ̇)`: Coriolis and centrifugal matrix
- `G(θ)`: Gravity vector
- `τ`: Applied joint torques

### Ball Aerodynamics
The ball trajectory includes:
- Gravitational force
- Aerodynamic drag: `F_d = -0.5 * ρ * Cd * A * |v|² * v̂`
- Magnus force (spin): `F_m = 0.5 * ρ * Cl * A * r * |ω| * |v| * (ω̂ × v̂)`

---

## Common Errors and Solutions

### "Not enough input arguments"
**Cause**: Functions were called directly without parameters.

**Solution**: These are functions, not scripts. Use the main script:
```matlab
>> run_tennis_simulation   % Correct
>> two_link_tennis_model   % Wrong - missing arguments!
```

Or call functions with proper arguments (see examples above).

---

## Output Files

Running `run_tennis_simulation` generates:
- `tennis_simulation_results.mat`: Complete results structure
- `tennis_simulation_report.txt`: Human-readable report
- Multiple figures showing joint angles, torques, and trajectories

---

## Requirements

- MATLAB R2018b or later
- No additional toolboxes required (uses only base MATLAB functions)

---

## Author

PhD Research Model - Tennis Biomechanics
Date: 2024
