function theta_ddot = compute_forward_dynamics(theta, theta_dot, tau, params)
%COMPUTE_FORWARD_DYNAMICS Computes joint accelerations from applied torques
%
% This function solves the forward dynamics problem: given the current state
% (joint angles and velocities) and applied torques, compute the resulting
% joint accelerations.
%
% Forward dynamics equation: theta_ddot = M^(-1) * (tau - C*theta_dot - G)
%
% Inputs:
%   theta     - Joint angles (rad) - nx1 vector where n is number of joints
%   theta_dot - Joint angular velocities (rad/s) - nx1 vector
%   tau       - Applied joint torques (Nm) - nx1 vector
%   params    - Structure containing model parameters (see two_link_tennis_model)
%
% Outputs:
%   theta_ddot - Joint angular accelerations (rad/s^2) - nx1 vector
%
% Example (2-link model):
%   params.l1 = 0.3; params.l2 = 0.35; params.m1 = 2; params.m2 = 1.5;
%   params.lc1 = 0.15; params.lc2 = 0.2; params.I1 = 0.025; params.I2 = 0.045;
%   params.g = 9.81;
%   theta = [0.5; 0.3]; theta_dot = [1; 0.5]; tau = [10; 5];
%   theta_ddot = compute_forward_dynamics(theta, theta_dot, tau, params);
%
% Author: PhD Research Model
% Date: 2024

%% Input Validation
if nargin < 4
    error('compute_forward_dynamics:NotEnoughInputs', ...
          ['Not enough input arguments.\n' ...
           'Usage: theta_ddot = compute_forward_dynamics(theta, theta_dot, tau, params)\n' ...
           'Run "help compute_forward_dynamics" for more information.']);
end

% Ensure column vectors
theta = theta(:);
theta_dot = theta_dot(:);
tau = tau(:);

% Validate dimensions match
n = length(theta);
if length(theta_dot) ~= n || length(tau) ~= n
    error('compute_forward_dynamics:DimensionMismatch', ...
          'theta, theta_dot, and tau must all have the same length');
end

%% Determine model type and compute dynamics matrices
if n == 2
    % Two-link model
    [M, C, G, ~] = two_link_tennis_model(theta, theta_dot, params);
elseif n == 3
    % Three-link model
    [M, C, G, ~] = three_link_tennis_model(theta, theta_dot, params);
else
    error('compute_forward_dynamics:UnsupportedModel', ...
          'Only 2-link and 3-link models are currently supported (n = %d given)', n);
end

%% Solve Forward Dynamics
% Forward dynamics: M * theta_ddot = tau - C * theta_dot - G
% Solve: theta_ddot = M \ (tau - C * theta_dot - G)

% Compute the right-hand side
rhs = tau - C * theta_dot - G;

% Solve the linear system (more numerically stable than direct inversion)
theta_ddot = M \ rhs;

% Ensure output is a column vector
theta_ddot = theta_ddot(:);

end
