%% TEST_ALL_FUNCTIONS - Verification Script for Tennis Biomechanics Model
% This script tests each function individually to verify they work correctly
% with proper input arguments.
%
% Author: PhD Research Model
% Date: 2024

clear; clc;
fprintf('=======================================================\n');
fprintf('  Testing All Functions - Tennis Biomechanics Model\n');
fprintf('=======================================================\n\n');

errors_found = 0;

%% Test 1: two_link_tennis_model
fprintf('Test 1: two_link_tennis_model... ');
try
    params = struct();
    params.l1 = 0.30; params.l2 = 0.35;
    params.m1 = 2.0; params.m2 = 1.5;
    params.lc1 = 0.15; params.lc2 = 0.20;
    params.I1 = 0.025; params.I2 = 0.045;
    params.g = 9.81;
    
    theta = [0.5; 0.3];
    theta_dot = [1.0; 0.5];
    
    [M, C, G, B] = two_link_tennis_model(theta, theta_dot, params);
    
    % Verify outputs
    assert(all(size(M) == [2, 2]), 'M should be 2x2');
    assert(all(size(C) == [2, 2]), 'C should be 2x2');
    assert(all(size(G) == [2, 1]), 'G should be 2x1');
    assert(all(size(B) == [2, 2]), 'B should be 2x2');
    assert(issymmetric(M), 'M should be symmetric');
    assert(all(eig(M) > 0), 'M should be positive definite');
    
    fprintf('PASSED\n');
catch ME
    fprintf('FAILED: %s\n', ME.message);
    errors_found = errors_found + 1;
end

%% Test 2: three_link_tennis_model
fprintf('Test 2: three_link_tennis_model... ');
try
    params = struct();
    params.l1 = 0.30; params.l2 = 0.25; params.l3 = 0.68;
    params.m1 = 2.0; params.m2 = 1.2; params.m3 = 0.34;
    params.lc1 = 0.15; params.lc2 = 0.12; params.lc3 = 0.34;
    params.I1 = 0.025; params.I2 = 0.015; params.I3 = 0.015;
    params.g = 9.81;
    
    theta = [0.5; 0.3; 0.1];
    theta_dot = [1.0; 0.5; 0.2];
    
    [M, C, G, B] = three_link_tennis_model(theta, theta_dot, params);
    
    % Verify outputs
    assert(all(size(M) == [3, 3]), 'M should be 3x3');
    assert(all(size(C) == [3, 3]), 'C should be 3x3');
    assert(all(size(G) == [3, 1]), 'G should be 3x1');
    assert(all(size(B) == [3, 3]), 'B should be 3x3');
    assert(issymmetric(M), 'M should be symmetric');
    assert(all(eig(M) > 0), 'M should be positive definite');
    
    fprintf('PASSED\n');
catch ME
    fprintf('FAILED: %s\n', ME.message);
    errors_found = errors_found + 1;
end

%% Test 3: compute_inverse_dynamics
fprintf('Test 3: compute_inverse_dynamics... ');
try
    params = struct();
    params.l1 = 0.30; params.l2 = 0.35;
    params.m1 = 2.0; params.m2 = 1.5;
    params.lc1 = 0.15; params.lc2 = 0.20;
    params.I1 = 0.025; params.I2 = 0.045;
    params.g = 9.81;
    
    theta = [0.5; 0.3];
    theta_dot = [1.0; 0.5];
    theta_ddot = [5.0; 3.0];
    
    tau = compute_inverse_dynamics(theta, theta_dot, theta_ddot, params);
    
    % Verify output
    assert(all(size(tau) == [2, 1]), 'tau should be 2x1');
    assert(all(isfinite(tau)), 'tau should be finite');
    
    fprintf('PASSED\n');
catch ME
    fprintf('FAILED: %s\n', ME.message);
    errors_found = errors_found + 1;
end

%% Test 4: compute_forward_dynamics
fprintf('Test 4: compute_forward_dynamics... ');
try
    params = struct();
    params.l1 = 0.30; params.l2 = 0.35;
    params.m1 = 2.0; params.m2 = 1.5;
    params.lc1 = 0.15; params.lc2 = 0.20;
    params.I1 = 0.025; params.I2 = 0.045;
    params.g = 9.81;
    
    theta = [0.5; 0.3];
    theta_dot = [1.0; 0.5];
    tau = [10.0; 5.0];
    
    theta_ddot = compute_forward_dynamics(theta, theta_dot, tau, params);
    
    % Verify output
    assert(all(size(theta_ddot) == [2, 1]), 'theta_ddot should be 2x1');
    assert(all(isfinite(theta_ddot)), 'theta_ddot should be finite');
    
    fprintf('PASSED\n');
catch ME
    fprintf('FAILED: %s\n', ME.message);
    errors_found = errors_found + 1;
end

%% Test 5: Forward-Inverse Dynamics Consistency
fprintf('Test 5: Forward-Inverse consistency... ');
try
    params = struct();
    params.l1 = 0.30; params.l2 = 0.35;
    params.m1 = 2.0; params.m2 = 1.5;
    params.lc1 = 0.15; params.lc2 = 0.20;
    params.I1 = 0.025; params.I2 = 0.045;
    params.g = 9.81;
    
    theta = [0.5; 0.3];
    theta_dot = [1.0; 0.5];
    theta_ddot_desired = [5.0; 3.0];
    
    % Compute torques from inverse dynamics
    tau = compute_inverse_dynamics(theta, theta_dot, theta_ddot_desired, params);
    
    % Compute accelerations from forward dynamics
    theta_ddot_recovered = compute_forward_dynamics(theta, theta_dot, tau, params);
    
    % They should match
    error_norm = norm(theta_ddot_desired - theta_ddot_recovered);
    assert(error_norm < 1e-10, 'Forward and inverse dynamics should be consistent');
    
    fprintf('PASSED (error = %.2e)\n', error_norm);
catch ME
    fprintf('FAILED: %s\n', ME.message);
    errors_found = errors_found + 1;
end

%% Test 6: ball_trajectory_simulator
fprintf('Test 6: ball_trajectory_simulator... ');
try
    ball_initial = struct();
    ball_initial.position = [0; 1.5; 0];
    ball_initial.velocity = [20; 5; 0];
    ball_initial.spin = [0; 0; -50];
    
    ball_params = struct();
    ball_params.mass = 0.057;
    ball_params.radius = 0.0335;
    ball_params.Cd = 0.55;
    ball_params.Cl = 0.25;
    ball_params.rho = 1.225;
    ball_params.g = 9.81;
    
    [time, state] = ball_trajectory_simulator(ball_initial, ball_params, 1.0);
    
    % Verify outputs
    assert(length(time) > 1, 'Should have multiple time points');
    assert(size(state, 2) == 6, 'State should have 6 columns');
    assert(size(state, 1) == length(time), 'State rows should match time length');
    
    % Ball should move forward
    assert(state(end,1) > state(1,1), 'Ball should move in positive x');
    
    fprintf('PASSED\n');
catch ME
    fprintf('FAILED: %s\n', ME.message);
    errors_found = errors_found + 1;
end

%% Test 7: ball_racket_toy
fprintf('Test 7: ball_racket_toy... ');
try
    ball_state = struct();
    ball_state.position = [0; 1; 0];
    ball_state.velocity = [-20; 0; 0];
    ball_state.spin = [0; 0; -50];
    ball_state.mass = 0.057;
    ball_state.radius = 0.0335;
    
    racket_state = struct();
    racket_state.position = [0; 1; 0];
    racket_state.velocity = [30; 5; 0];
    racket_state.normal = [1; 0; 0];
    
    ball_params = struct();
    ball_params.e = 0.75;
    ball_params.mu = 0.4;
    
    [post_vel, post_spin] = ball_racket_toy(ball_state, racket_state, ball_params);
    
    % Verify outputs
    assert(all(size(post_vel) == [3, 1]), 'post_velocity should be 3x1');
    assert(all(size(post_spin) == [3, 1]), 'post_spin should be 3x1');
    assert(all(isfinite(post_vel)), 'post_velocity should be finite');
    assert(all(isfinite(post_spin)), 'post_spin should be finite');
    
    % Ball should reverse direction (approximately)
    assert(post_vel(1) > 0, 'Ball should move in positive x after impact');
    
    fprintf('PASSED\n');
catch ME
    fprintf('FAILED: %s\n', ME.message);
    errors_found = errors_found + 1;
end

%% Test 8: generate_enhanced_summary_report
fprintf('Test 8: generate_enhanced_summary_report... ');
try
    % Create minimal results structure
    results = struct();
    results.time = (0:0.01:0.5)';
    
    results.params_2link = struct();
    results.params_2link.l1 = 0.3;
    results.params_2link.l2 = 0.35;
    results.params_2link.m1 = 2.0;
    results.params_2link.m2 = 1.5;
    
    results.two_link = struct();
    results.two_link.theta = rand(length(results.time), 2);
    results.two_link.theta_dot = rand(length(results.time), 2);
    results.two_link.tau = rand(length(results.time), 2) * 10;
    results.two_link.racket_speed = rand(length(results.time), 1) * 30;
    
    generate_enhanced_summary_report(results, 'test_report.txt');
    
    % Verify file was created
    assert(exist('test_report.txt', 'file') == 2, 'Report file should be created');
    
    % Clean up
    delete('test_report.txt');
    
    fprintf('PASSED\n');
catch ME
    fprintf('FAILED: %s\n', ME.message);
    errors_found = errors_found + 1;
end

%% Summary
fprintf('\n=======================================================\n');
if errors_found == 0
    fprintf('  ALL TESTS PASSED! (%d/8)\n', 8);
    fprintf('  The model is ready to use.\n');
else
    fprintf('  TESTS COMPLETED: %d passed, %d failed\n', 8 - errors_found, errors_found);
    fprintf('  Please review failed tests.\n');
end
fprintf('=======================================================\n');

%% Helper function
function tf = issymmetric(M)
    tf = norm(M - M', 'fro') < 1e-10;
end
